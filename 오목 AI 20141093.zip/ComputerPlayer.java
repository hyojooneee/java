package ����;

public class ComputerPlayer extends Player {

	private int evaluatePosition(OmokBoard _board, int _x, int _y) {

		int[] mycount = new int[4];

		int[] opcount = new int[4];
		for (int i = 0; i < 4; i++) {
			mycount[i] = 0;
			opcount[i] = 0;
		}
		StoneType me = StoneType.Black;// com
		StoneType op = StoneType.White;
		int[] score = new int[4];
		int max = 0;

		// 1. ���� ���� ������ ��� 5�� �ϼ�

		Position m = new Position(_x, _y);
		_board.countSameColorStones(m, me, mycount);
		for (int i = 0; i < 4; i++) {
			if (mycount[i] == 4) {
				return 100;
			}
			mycount[i] = 0; // ī��Ʈ �迭 �ʱ�ȭ
		}

		// 2. ������ ���� ������ ��쿡 5�� �ϼ�
		_board.countSameColorStones(m, op, opcount);
		for (int i = 0; i < 4; i++) {
			if (opcount[i] == 4) {
				return 90;
			}
			opcount[i] = 0; // ī��Ʈ �迭 �ʱ�ȭ
		}

		_board.countSameColorStones(m, me, mycount); // ����
		_board.countSameColorStones(m, op, opcount); // ������
		for (int i = 0; i < 4; i++) {
				if (mycount[i] == 3 && isBlocked(i, _board, _x, _y) == false) // 3.
				{
					score[i] = 80;
				} else if (opcount[i] == 3 && isBlocked(i, _board, _x, _y) == false) // 4.
				{
					score[i] = 75;
				} else if (mycount[i] == 3 && isBlocked(i, _board, _x, _y) == true) // 5.
				{
					score[i] = 70;
				} else if (opcount[i] == 3 && isBlocked(i, _board, _x, _y) == true) // 6.
				{
					score[i] = 65;
				} else if (mycount[i] == 2 && isBlocked(i, _board, _x, _y) == false) // 7.
				{
					score[i] = 60;
				} else if (opcount[i] == 2 && isBlocked(i, _board, _x, _y) == false) // 8.
				{
					score[i] = 55;
				} else if (mycount[i] == 2 && isBlocked(i, _board, _x, _y) == true) // 9.
				{
					score[i] = 50;
				} else if (opcount[i] == 2 && isBlocked(i, _board, _x, _y) == true) // 10.
				{
					score[i] = 45;
				} else if (mycount[i] == 1 && isBlocked(i, _board, _x, _y) == false) // 11.
				{
					score[i] = 40;

				} else if (opcount[i] == 1 && isBlocked(i, _board, _x, _y) == false) // 12.
				{
					score[i] = 35;

				} else if (mycount[i] == 1 && isBlocked(i, _board, _x, _y) == true) // 13.
				{
					score[i] = 30;

				} else if (opcount[i] == 1 && isBlocked(i, _board, _x, _y) == true) // 14.
				{
					score[i] = 25;

				} else if (mycount[i] == 0 && isBlocked(i, _board, _x, _y) == false) // 15.
				{
					score[i] = 20;

				} else if (opcount[i] == 0 && isBlocked(i, _board, _x, _y) == false) // 16.
				{
					score[i] = 15;

				} else if (mycount[i] == 0 && isBlocked(i, _board, _x, _y) == true) // 17.
				{
					score[i] = 10;

				} else if (opcount[i] == 0 && isBlocked(i, _board, _x, _y) == true) // 18.
				{
					score[i] = 5;
				} else {
					score[i] = 0;
				}
		}

		for (int i = 0; i < 4; i++) {
			if (max < score[i]) {
				max = score[i];
			}

		}
		return max;
	}

	public boolean isBlocked(int i, OmokBoard _board, int _x, int _y) {
		int size = _board.getSize();
		boolean block = false;
		switch (i) {
		case 0:
			for (int k = 1; k < 5; k++) // ��
			{
				if (_y + k < size) {
					if (_board.getStone(_x, _y + k) == StoneType.White)
						block = true;
					break;
				}
				
			}
			for (int k = 1; k < 5; k++) // ��
			{
				if (0 <= _y - k) {
					if (_board.getStone(_x, _y - k) == StoneType.White)
						block = true;
					break;
				}
			}
			

		case 1:
			for (int k = 1; k < 5; k++) // ����
			{
				if (_x + k < size && _y + k < size) {
					if (_board.getStone(_x + k, _y + k) == StoneType.White)
						block = true;
					break;
				}
			}
			for (int k = 1; k < 5; k++) // �ϼ�
			{
				if (0 <= _x - k  && 0 <= _y - k) {
					if (_board.getStone(_x - k, _y - k) == StoneType.White)
						block = true;
					break;
				}
			}

		case 2:
			for (int k = 1; k < 5; k++) // ��
			{
				if (_x + k < size) {
					if (_board.getStone(_x + k, _y) == StoneType.White)
						block = true;
					break;
				}
			}
			for (int k = 1; k < 5; k++) // ��
			{
				if (0<=_x - k) {
					if (_board.getStone(_x - k, _y) == StoneType.White)
						block = true;
					break;
				}
			}
		case 3:
			for (int k = 1; k < 5; k++) // ����
			{
				if (_x + k < size && 0<=_y - k) {
					if (_board.getStone(_x + k, _y - k) == StoneType.White)
						block = true;
					break;
				}
			}
			for (int k = 1; k < 5; k++) // �ϵ�
			{
				if (0<=_x - k  && _y + k < size) {
					if (_board.getStone(_x - k, _y + k) == StoneType.White)
						block = true;
					break;
				}
			}
		}
		return block;
	}

	public ComputerPlayer(int _id, String _name, int _order, int _playType) {
		id = _id;
		name = _name;
		order = _order;
		playerType = _playType;
	}

	public Position play(OmokBoard _board) {
		int size = _board.getSize();
		int[][] valBoard = new int[size][size]; // �� �ڸ����� ������

		// ���ʽ� ���� + �� �ڸ� ���� ����
		int center = (size / 2);
		int sector = ((size / 2) / 5);
		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				if (_board.getStone(i, j) != StoneType.None) // �̹� ������ �ִ� ���ڸ��� 0
																// ����
					valBoard[i][j] = 0;
				else if (center - (sector * 1) < i && i < center + (sector * 1) && center - (sector * 1) < j
						&& j < center + (sector * 1)) { // 1����
					valBoard[i][j] = 5 + evaluatePosition(_board, i, j);
				} else if (center - (sector * 2) < i && i < center + (sector * 2) && center - (sector * 2) < j
						&& j < center + (sector * 2)) { // 2����
					valBoard[i][j] = 4 + evaluatePosition(_board, i, j);
				} else if (center - (sector * 3) < i && i < center + (sector * 3) && center - (sector * 3) < j
						&& j < center + (sector * 3)) { // 3����
					valBoard[i][j] = 3 + evaluatePosition(_board, i, j);
				} else if (center - (sector * 4) < i && i < center + (sector * 4) && center - (sector * 4) < j
						&& j < center + (sector * 4)) { // 4����
					valBoard[i][j] = 2 + evaluatePosition(_board, i, j);
				} else { // 5����
					valBoard[i][j] = 1 + evaluatePosition(_board, i, j);
				}

			}
		}

		/*for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				System.out.print(valBoard[i][j] + " ");
			}
			System.out.println();
		}*/

		// �ִ� �������� x, y �޾ƿ���
		int maxScore = 0;
		int row = 0;
		int col = 0;

		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				if (maxScore < valBoard[i][j]) {
					maxScore = valBoard[i][j];
					row = i;
					col = j;

				}
			}
		}
		/*System.out.println(maxScore);*/

		// �� ���� ��ġ ����
		Position cm = new Position(col, row);

		return cm;
	}

}
