package ����;

import java.util.Scanner;

public class Player {
	Scanner s = new Scanner(System.in);
	protected int id;
	protected int order;
	protected int playerType; // 1. ��� 2. ���̹�
	protected double winningRate;
	protected String name;

	public Player(int _id, String _name, int _order, int _playerType) {
		id = _id;
		name = _name;
		order = _order;
		playerType = _playerType;
	}

	public Player() {
	}

	public int getID() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getOrder() {
		return order;
	}

	public double getWinningRate() {
		return winningRate;
	}

	public int getPlayerType() {
		return playerType;
	}

	public Position play(OmokBoard _bBoard) {
		int x, y;
		System.out.print("X �� �Է����ּ��� : ");
		x = s.nextInt();
		System.out.print("Y �� �Է����ּ��� : ");
		y = s.nextInt();
		Position m = new Position(x, y);

		return m;
	}

	public void setWinningRate(double _winningRate) {
		winningRate = _winningRate;
	}

	public void setName(String _name) {
		name = _name;
	}

	public void setOrder(int _order) {
		order = _order;
	}

}
