package ����;

enum StoneType {
	None, Black, White
};

public class OmokBoard {
	private int ROWS; // ���� ��
	private int COLS; // ���� ��
	private int SIZE;
	private StoneType matrix[][];

	public OmokBoard() {
		ROWS = 19;
		COLS = 19;
		matrix = new StoneType[ROWS][COLS];
		clear();
	}

	public OmokBoard(int _size) {
		switch (_size) {
		case 0:
			ROWS = 10;
			COLS = 10;
			SIZE = 10;
			break;
		case 1:
			ROWS = 15;
			COLS = 15;
			SIZE = 15;
			break;
		case 2:
			ROWS = 19;
			COLS = 19;
			SIZE = 19;
			break;
			
		default:
			System.out.println("0,1,2 �̿��� ���� �Է� �ϼ����Ƿ� ����Ʈ�� 19x19�� �����մϴ�.");
			ROWS = 19;
			COLS = 19;
			SIZE = 19;
			break;
		}
		matrix = new StoneType[ROWS][COLS];
		clear();

	}

	public OmokBoard(int _ROWS, int _COLS) {
		ROWS = _ROWS;
		COLS = _COLS;
		matrix = new StoneType[ROWS][COLS];
		clear();
	}

	public void putStone(int x, int y, StoneType stone) {
		matrix[x][y] = stone;
	}

	public void removeStone(int x, int y) {
		matrix[x][y] = StoneType.None;
	}

	public StoneType getStone(int x, int y) {
		return matrix[x][y];
	}

	public void clear() {
		for (int i = 0; i < ROWS; i++) {
			for (int j = 0; j < COLS; j++) {
				matrix[i][j] = StoneType.None;
			}
		}
	}

	public int getRowCount() {
		return ROWS;
	}

	public int getColCount() {
		return COLS;
	}
	
	public int getSize(){return SIZE;}

	public void countSameColorStones(Position m, StoneType color, int[] stoneNum) {
		int x = m.getColumn();
		int y = m.getRow();

		for (int i = 1; i < 5; i++) // ��
		{
			if (x + i < (SIZE/2) && y + i < (SIZE/2)) {
				if (color == matrix[x][y + i])
					stoneNum[0]++;
			}
		}

		for (int i = 1; i < 5; i++) // ����
		{
			if (x + i < (SIZE/2) && y + i < (SIZE/2)) {
				if (color == matrix[x + i][y + i])
					stoneNum[1]++;
			}
		}

		for (int i = 1; i < 5; i++) // ��
		{
			if (x + i < (SIZE/2)) {
				if (color == matrix[x + i][y])
					stoneNum[2]++;
			}
		}

		for (int i = 1; i < 5; i++) // ����
		{
			if (x + i < (SIZE/2) && 0 <= y - i) {
				if (color == matrix[x + i][y - i])
					stoneNum[3]++;
			}
		}

		for (int i = 1; i < 5; i++) // ��
		{
			if (x + i < (SIZE/2) && 0 <= y - i) {
				if (color == matrix[x][y - i])
					stoneNum[0]++;
			}
		}

		for (int i = 1; i < 5; i++) // �ϼ�
		{
			if (0 <= x - i && 0 <= y - i) {
				if (color == matrix[x - i][y - i])
					stoneNum[1]++;
			}
		}

		for (int i = 1; i < 5; i++) // ��
		{
			if (0 <= x - i) {
				if (color == matrix[x - i][y])
					stoneNum[2]++;
			}
		}

		for (int i = 1; i < 5; i++) // �ϵ�
		{
			if (0 <= x - i && y + i < (SIZE/2)) {
				if (color == matrix[x - i][y + i])
					stoneNum[3]++;
			}
		}


	}
}
