package ����;

public class Main {
	public static void main(String[] args){
		Match game = new Match();
		game.start();
	}
}
