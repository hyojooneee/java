package ����;

import java.util.Scanner;

public class Match {
	Scanner s = new Scanner(System.in);
	private Player[] players;
	private int turn;
	private int playType;
	private OmokBoard playBoard;
	private int boardSize; // 0�̸� 10x10 , 1�̸� 15x15 , 2�̸� 19x19
	private int[] compass; // 4����

	public Match() {
		players = new Player[2];
		boardSize = 2;

		System.out.print("Size �ɼ��� �Է��ϼ���(0 : 10x10 / 1 : 15x15 / 2 : 19x19) : ");
		boardSize = s.nextInt();
		playBoard = new OmokBoard(boardSize);

		System.out.println("play �ɼ��� �Է��ϼ���(1 : ��� vs ��� / 2 : ��� vs ��ǻ��)");
		int playOption = s.nextInt();
		if(playOption == 1)
		{
		players[0] = new Player();
		players[1] = new Player();
		compass = new int[4];
		setPlayers();

		}
		else if(playOption == 2)
		{
		players[0] = new Player();
		players[1] = new ComputerPlayer(2,"computer",2,2);
		compass = new int[4];
		System.out.print("�÷��̾��� �̸� : ");
		s.nextLine();
		players[0].setName(s.nextLine());
		players[0].setOrder(1);

		}
		else
		{
			System.out.println("1,2 �̿��� ���� �Է� �ϼ����Ƿ� ��� vs ��ǻ�ͷ� ����˴ϴ�.");
			players[0] = new Player();
			players[1] = new ComputerPlayer(2,"computer",2,2);
			compass = new int[4];
			System.out.print("�÷��̾��� �̸� : ");
			s.nextLine();
			players[0].setName(s.nextLine());
			players[0].setOrder(1);

		}

	}

	private boolean checkWinningCondition()// ��, �и� ������ �� �ִ���
	{
		for (int i = 0; i < 4; i++) {
			if (compass[i] == 4)
				return true;
		}
		return false;
	}

	private boolean checkValidity(Position m)// ���� ���� �� �ִ���
	{
		int a = playBoard.getColCount();
		int b = playBoard.getRowCount();
		int x = m.getColumn();
		int y = m.getRow();
		if (x >= a && x >= 0 || y >= b && y >= 0) {
			System.out.println(a + " by " + b + " �� �Է����ּ���.");
			return false;
		}
		if (playBoard.getStone(x, y) != StoneType.None) {
			System.out.println("�̹� ���� �������ֽ��ϴ�. �ٽ��Է����ּ���.");
			return false;
		} else {
			System.out.println(y + " " + x + " �� ���� ���ҽ��ϴ�.");
			return true;
		}
	}

	public int getTurn() {
		return turn;
	}

	public void setTurn(int n) {
		turn = n;
	}

	public Player getPlayer(int n) {
		return players[n];
	}

	public Player getCurrentPlayer() {
		return players[turn];
	}

	public StoneType getCurrentColor() {
		if (turn % 2 == 0) {
			return StoneType.Black;
		} else
			return StoneType.White;
	}

	public OmokBoard getBoard() {
		return playBoard;
	}

	public void setPlayer(int n, Player player) {
		players[n] = player;
	}

	public int getPlayerType() {
		return playType;
	}

	public void setPlayerType(int n) {
		playType = n;
	}

	public void display() {
		
		int a = playBoard.getColCount();
		int b = playBoard.getRowCount();
		
		System.out.print("   ");
		for(int i = 0 ; i < a;i++)
		{
			if(i<10)
			System.out.print(i+"  ");
			else
				System.out.print(i+" ");
		}
		System.out.println();
		for (int i = 0; i < a; i++) {
			if(i<10)
			System.out.print(i+" ");
			else
				System.out.print(i);
			for (int j = 0; j < b; j++) {
				
				if (playBoard.getStone(i, j) == StoneType.White)
					System.out.print(" o ");
				else if (playBoard.getStone(i, j) == StoneType.Black)
					System.out.print(" x ");
				else
					System.out.print(" �� ");
			}
			System.out.println();
		}
	}

	public void setPlayers() {
		System.out.print("ù ��° �÷��̾��� �̸� : ");
		s.nextLine();
		players[0].setName(s.nextLine());
		players[0].setOrder(1);
		System.out.print("�� ��° �÷��̾��� �̸� : ");
		players[1].setName(s.nextLine());
		players[1].setOrder(2);
	}

	public void start() {
		int win1 = 0, win2 = 0, matchNum = 0;
		boolean b;
		Position m;
		while (true) {
			for (int i = 0; i < 4; i++) {
				compass[i] = 0;
			}

			if (turn % 2 == 0) 
			{
				while (true) {
					System.out.println(players[0].getName() + "���� �����Դϴ�.");
					m = players[0].play(playBoard);
					b = checkValidity(m);
					if (b == true) {
						playBoard.putStone(m.getColumn(), m.getRow(), StoneType.White);
						turn++;
						playBoard.countSameColorStones(m, StoneType.White, compass);
						display();
						break;
					}
				}
				if (checkWinningCondition() == true) {
					System.out.println(players[0].getName() + " is Winner");
					playBoard.clear();
					win1++;
					matchNum++;
					players[0].setWinningRate((win1 / matchNum) * 100);
					System.out.println(players[0].getName() + " �� �·� : " + players[0].getWinningRate());
				}

			} 
			else 
			{
				for (int i = 0; i < 4; i++) {
					compass[i] = 0;
				}
				while (true) {
					System.out.println(players[1].getName() + "���� �����Դϴ�.");
					m = players[1].play(playBoard);
					b = checkValidity(m);
					if (b == true) {
						playBoard.putStone(m.getColumn(), m.getRow(), StoneType.Black);
						turn++;
						playBoard.countSameColorStones(m, StoneType.Black, compass);
						display();
						break;
					}
					
				}

				if (checkWinningCondition() == true) {
					System.out.println(players[1].getName() + " is Winner");
					playBoard.clear();
					win2++;
					matchNum++;
					System.out.println((win2 / matchNum) * 100);
					players[1].setWinningRate((win2 / matchNum) * 100);
					System.out.println(players[1].getName() + " �� �·� : " + players[1].getWinningRate());
				}
			}
		}
	}
	

	
}
